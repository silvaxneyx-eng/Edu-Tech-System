param(
    [string]$Destino = (Join-Path $env:USERPROFILE "Desktop\Backup-Perfil-$(Get-Date -Format 'yyyyMMdd')")
)

$ErrorActionPreference = 'Continue'

$perfisDisponiveis = @(
    'Desktop',
    'Documents',
    'Pictures',
    'Downloads',
    'Videos',
    'Music',
    'Favorites'
)

$origens = @()
foreach ($p in $perfisDisponiveis) {
    $caminho = Join-Path $env:USERPROFILE $p
    if (Test-Path -LiteralPath $caminho) {
        $origens += [PSCustomObject]@{ Nome = $p; Caminho = $caminho }
    }
}

# Bookmarks do Navegador (Chrome e Edge)
$chromeBookmarks = Join-Path $env:LOCALAPPDATA 'Google\Chrome\User Data\Default\Bookmarks'
$edgeBookmarks = Join-Path $env:LOCALAPPDATA 'Microsoft\Edge\User Data\Default\Bookmarks'

if (Test-Path -LiteralPath $chromeBookmarks) {
    $origens += [PSCustomObject]@{ Nome = 'Chrome Bookmarks'; Caminho = $chromeBookmarks }
}
if (Test-Path -LiteralPath $edgeBookmarks) {
    $origens += [PSCustomObject]@{ Nome = 'Edge Bookmarks'; Caminho = $edgeBookmarks }
}

Write-Host "=== BACKUP DO PERFIL DE USUÁRIO ===" -ForegroundColor Cyan
Write-Host "Destino planejado: $Destino`n"

# 1. Calcular tamanho estimado
Write-Host "Calculando tamanho dos arquivos do perfil (isso pode levar segundos)..." -ForegroundColor Gray
$tamanhoTotalBytes = 0
foreach ($origem in $origens) {
    if (Test-Path -LiteralPath $origem.Caminho) {
        if ($_ -is [System.IO.DirectoryInfo] -or (Get-Item $origem.Caminho) -is [System.IO.DirectoryInfo]) {
            $tamanho = (Get-ChildItem -LiteralPath $origem.Caminho -Recurse -File -Force -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
            if ($tamanho) { $tamanhoTotalBytes += $tamanho }
        } else {
            $tamanhoTotalBytes += (Get-Item $origem.Caminho).Length
        }
    }
}

$tamanhoMB = [math]::Round($tamanhoTotalBytes / 1MB, 2)
$tamanhoGB = [math]::Round($tamanhoTotalBytes / 1GB, 2)
$exibirTamanho = if ($tamanhoGB -gt 1) { "$tamanhoGB GB" } else { "$tamanhoMB MB" }

Write-Host "Tamanho total estimado: $exibirTamanho" -ForegroundColor Yellow

# Verificar espaço no destino
$driveDest = (Get-Item -LiteralPath (Split-Path $Destino)).PSDrive.Name + ":"
if ($driveDest) {
    $espacoLivreDest = (Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='$driveDest'" -ErrorAction SilentlyContinue).FreeSpace
    if ($espacoLivreDest -and $espacoLivreDest -lt $tamanhoTotalBytes) {
        $espacoGB = [math]::Round($espacoLivreDest / 1GB, 2)
        Write-Warning "Espaço insuficiente no destino ($driveDest tem apenas $espacoGB GB livres)!"
        $confirmar = Read-Host "Deseja continuar mesmo assim? (S/N)"
        if ($confirmar -notlike 's*') {
            Write-Host "Operação abortada." -ForegroundColor Red
            exit 1
        }
    }
}

# Criar pasta destino
New-Item -ItemType Directory -Path $Destino -Force | Out-Null

# 2. Copiar com barra de progresso
$totalItens = $origens.Count
$i = 0

foreach ($origem in $origens) {
    $i++
    $porcentagem = [math]::Round(($i / $totalItens) * 100)
    Write-Progress -Activity "Realizando Backup de Perfil" -Status "Copiando $($origem.Nome)..." -PercentComplete $porcentagem
    
    Write-Host "Copiando $($origem.Nome)..." -ForegroundColor Cyan
    $destinoItem = Join-Path $Destino $origem.Nome
    
    try {
        if (Test-Path -LiteralPath $origem.Caminho) {
            if ((Get-Item $origem.Caminho) -is [System.IO.DirectoryInfo]) {
                New-Item -ItemType Directory -Path $destinoItem -Force | Out-Null
                Copy-Item -LiteralPath "$($origem.Caminho)\*" -Destination $destinoItem -Recurse -Force -ErrorAction SilentlyContinue
            } else {
                Copy-Item -LiteralPath $origem.Caminho -Destination $Destino -Force -ErrorAction SilentlyContinue
            }
        }
    } catch {
        Write-Warning "Falha ao copiar parte de $($origem.Nome): $($_.Exception.Message)"
    }
}

Write-Progress -Activity "Realizando Backup de Perfil" -Completed
Write-Host "`nBackup concluído com sucesso em: $Destino" -ForegroundColor Green
