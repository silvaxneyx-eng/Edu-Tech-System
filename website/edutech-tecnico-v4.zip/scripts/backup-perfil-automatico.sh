#!/bin/bash
# Backup automático do perfil do usuário Windows
# Detecta as partições, encontra as pastas do usuário e copia para um HD externo

echo "============================================="
echo "   ISO LOUCA - BACKUP AUTOMÁTICO DE PERFIL   "
echo "============================================="
echo ""

# Detecta partições disponíveis para usar como destino do backup
echo "Partições disponíveis para salvar o backup (Pendrives / HDs Externos):"
lsblk -lo NAME,SIZE,FSTYPE,LABEL,MOUNTPOINT | grep -v "loop" | grep -E "vfat|exfat|ntfs|ext4"
echo ""

read -p "Digite o NOME da partição de destino (ex: sda1 ou sdb1): " destino_dev
destino_mount="/mnt/backup_destino"
mkdir -p "$destino_mount"
mount "/dev/$destino_dev" "$destino_mount" 2>/dev/null

if [ ! -d "$destino_mount" ] || ! mountpoint -q "$destino_mount"; then
    echo "Erro: Não conseguiu montar /dev/$destino_dev"
    exit 1
fi

backup_dir="$destino_mount/Backup-$(date +%Y%m%d-%H%M)"
mkdir -p "$backup_dir"

# Monta partições NTFS do Windows
particoes=$(lsblk -lo NAME,FSTYPE | grep -i ntfs | awk '{print $1}')

if [ -z "$particoes" ]; then
    echo "Nenhuma partição NTFS encontrada."
    umount "$destino_mount"
    exit 1
fi

for part in $particoes; do
    device="/dev/$part"
    mount_point="/mnt/win_$part"
    mkdir -p "$mount_point"
    mount -t ntfs-3g -o ro "$device" "$mount_point" 2>/dev/null

    # Procura pela pasta Users (Windows Vista+)
    users_path=""
    if [ -d "$mount_point/Users" ]; then
        users_path="$mount_point/Users"
    elif [ -d "$mount_point/Documents and Settings" ]; then
        users_path="$mount_point/Documents and Settings"
    fi

    if [ -z "$users_path" ]; then
        umount "$mount_point" 2>/dev/null
        continue
    fi

    echo "Encontrado pasta de usuários em $device"
    echo ""

    # Lista os perfis de usuário (ignora pastas do sistema)
    for user_dir in "$users_path"/*/; do
        user_name=$(basename "$user_dir")

        # Ignora perfis do sistema
        case "$user_name" in
            "Public"|"Default"|"Default User"|"All Users"|"desktop.ini") continue ;;
        esac

        echo "Copiando perfil de: $user_name"
        user_backup="$backup_dir/$user_name"
        mkdir -p "$user_backup"

        # Copia as pastas essenciais
        for pasta in "Desktop" "Documents" "Downloads" "Pictures" "Videos" "Music" "Favorites"; do
            src="$user_dir/$pasta"
            if [ -d "$src" ]; then
                echo "  → $pasta..."
                cp -r "$src" "$user_backup/" 2>/dev/null
            fi
        done

        echo "  ✅ Perfil de $user_name copiado."
        echo ""
    done

    umount "$mount_point" 2>/dev/null
done

# Resumo
total=$(du -sh "$backup_dir" 2>/dev/null | awk '{print $1}')
echo "============================================="
echo "  BACKUP CONCLUÍDO!"
echo "  Destino: $backup_dir"
echo "  Tamanho total: $total"
echo "============================================="

umount "$destino_mount" 2>/dev/null
